
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button createAccountButton;
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameEditText = findViewById(R.id.editTextTextUsernameCreate);
        passwordEditText = findViewById(R.id.editTextTextPasswordCreate);
        createAccountButton = findViewById(R.id.createAccountPage);

        userRepository = new UserRepository(this);
        userRepository.open();

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    // This should display an error message if username or password is empty.
                    Toast.makeText(CreateAccountActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    // This should check if the username is already taken.
                    if (!userRepository.isUsernameTaken(username)) {
                        // This should create a new user and add it to the database.
                        User newUser = new User(username, password);
                        long userId = userRepository.createUser(newUser);

                        if (userId != -1) {
                            // This should see if the user was created successfully.
                            Toast.makeText(CreateAccountActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                            // This should navigate back to the login page.
                            navigateToLoginPage();
                        } else {
                            // This should show if there was an error creating the user.
                            Toast.makeText(CreateAccountActivity.this, "Error creating account. Please try again", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // This should show if the username is already taken.
                        Toast.makeText(CreateAccountActivity.this, "Username is already taken. Please choose another", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void navigateToLoginPage() {
        Intent loginIntent = new Intent(this, MainActivity.class);
        startActivity(loginIntent);
        finish(); // This should finish the current activity to prevent going back to it using the back button.
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userRepository.close();
    }
}

