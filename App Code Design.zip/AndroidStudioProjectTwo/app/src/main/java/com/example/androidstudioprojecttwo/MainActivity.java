
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;


public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;
    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.editTextTextUsernameCreate);
        passwordEditText = findViewById(R.id.editTextTextPasswordCreate);
        loginButton = findViewById(R.id.button3);
        createAccountButton = findViewById(R.id.buttonCreateAccount);

        userRepository = new UserRepository(this);
        userRepository.open();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (userRepository.isValidUser(username, password)) {
                    // This should run if there was a successful login.
                    showNotificationConfirmationDialog();
                    Toast.makeText(MainActivity.this, "Credentials match", Toast.LENGTH_SHORT).show();

                } else {
                    // This should run if there was an invalid login.
                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This should check if "Create Account" button is clicked, if so, navigate to the activity_create_account.xml page.
                Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showNotificationConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enable SMS Notifications?");
        builder.setMessage("Do you want to enable SMS notifications?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // This should check if the user clicks yes.
                Intent notificationIntent = new Intent(MainActivity.this, DailyWeightActivity.class);
                // This should enable notifications.
                setNotificationPreferences(true);
                startActivity(notificationIntent);
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // This should check if the user clicks no.
                Intent dailyWeightIntent = new Intent(MainActivity.this, DailyWeightActivity.class);
                // This should disable notifications.
                setNotificationPreferences(false);
                startActivity(dailyWeightIntent);
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void setNotificationPreferences(boolean notificationsEnabled) {
        SharedPreferences preferences = getSharedPreferences("NotificationPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("notificationsEnabled", notificationsEnabled);
        editor.apply();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userRepository.close();
    }

}
