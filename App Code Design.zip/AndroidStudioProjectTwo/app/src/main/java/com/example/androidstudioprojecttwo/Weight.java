
// Nate Bennett

package com.example.androidstudioprojecttwo;

public class Weight {
    private long id;
    private double weight;
    private String date;

    public Weight(long id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public long getId() {
        return id;
    }

    public double getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}
