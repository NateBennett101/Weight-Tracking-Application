
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import androidx.appcompat.app.AlertDialog;
import android.text.InputType;
import android.content.DialogInterface;



public class DailyWeightActivity extends AppCompatActivity {

    private EditText weightEditText;
    private Button addWeightButton;
    private TableLayout tableLayoutWeights;
    private EditText goalWeightEditText;
    private Button submitGoalWeightButton;
    private TextView goalWeightTextView;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_weight);

        // This should create a notification channel.
        NotificationChannel channel = new NotificationChannel("channel_id", "Channel Name", NotificationManager.IMPORTANCE_DEFAULT);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);

        weightEditText = findViewById(R.id.editTextWeight);
        addWeightButton = findViewById(R.id.buttonAddWeight);
        tableLayoutWeights = findViewById(R.id.tableLayoutWeights);
        goalWeightEditText = findViewById(R.id.editTextGoalWeight);
        submitGoalWeightButton = findViewById(R.id.buttonSubmitGoalWeight);
        goalWeightTextView = findViewById(R.id.textViewGoalWeight);

        // This should create the database and table.
        database = openOrCreateDatabase("user_db", MODE_PRIVATE, null);
        createTable();

        // This should display existing weights.
        displayWeights();

        // This should display the current goal weight.
        displayGoalWeight();

        // This should set a listener for adding daily weight.
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WeightRepository weightRepository = new WeightRepository(DailyWeightActivity.this);
                // This should ensure the database is opened before using it.
                weightRepository.open();

                String weightStr = weightEditText.getText().toString();

                if (!weightStr.isEmpty()) {
                    double weight = Double.parseDouble(weightStr);

                    // This should add the daily weight to the database.
                    addDailyWeight(weight);

                    // This should check if entered weight matches goal weight.
                    double goalWeight = weightRepository.getGoalWeight("1");

                    if (weight == goalWeight) {
                        // This should check if user has accepted notifications.
                        SharedPreferences preferences = getSharedPreferences("NotificationPreferences", MODE_PRIVATE);
                        boolean notificationsEnabled = preferences.getBoolean("notificationsEnabled", false);

                        if (notificationsEnabled) {
                            // This should create a notification.
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(DailyWeightActivity.this, "channel_id")
                                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                                    .setContentTitle("Congratulations!")
                                    .setContentText("You have reached your goal weight.")
                                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                            // This should get the NotificationManager.
                            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(DailyWeightActivity.this);

                            int notificationId = 1;

                            // This should show the notification.
                            notificationManager.notify(notificationId, builder.build());
                        }
                    }

                    // This should display the added weight in the table.
                    displayWeights();

                    // This should display a success message.
                    Toast.makeText(DailyWeightActivity.this, "Weight added successfully", Toast.LENGTH_SHORT).show();
                } else {
                    // This should display an error message if weight is empty.
                    Toast.makeText(DailyWeightActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                }

                // This should close the repository when you're done using it.
                weightRepository.close();
            }
        });


        // This should set a listener for submitting goal weight.
        submitGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalWeightStr = goalWeightEditText.getText().toString();

                if (!goalWeightStr.isEmpty()) {
                    double goalWeight = Double.parseDouble(goalWeightStr);

                    // This should add the goal weight to the database.
                    addGoalWeight(goalWeight);

                    // This should display the goal weight.
                    displayGoalWeight();
                } else {
                    Toast.makeText(DailyWeightActivity.this, "Please enter a valid goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void createTable() {
        try {
            database.execSQL("CREATE TABLE IF NOT EXISTS weights (weight_id INTEGER PRIMARY KEY AUTOINCREMENT, weight REAL, date TEXT)");
            database.execSQL("CREATE TABLE IF NOT EXISTS goal_weights (goal_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, goal_weight REAL)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addDailyWeight(double weight) {
        try {
            String currentDate = getCurrentDate();
            database.execSQL("INSERT INTO weights (weight, date) VALUES (" + weight + ", '" + currentDate + "')");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addGoalWeight(double goalWeight) {
        WeightRepository weightRepository = new WeightRepository(this);
        weightRepository.open();
        weightRepository.addGoalWeight("1", goalWeight);
        weightRepository.close();
    }

    private void displayWeights() {
        tableLayoutWeights.removeAllViews();

        Cursor cursor = database.rawQuery("SELECT * FROM weights", null);

        if (cursor.moveToFirst()) {
            do {
                double weight = cursor.getDouble(cursor.getColumnIndex("weight"));
                String date = cursor.getString(cursor.getColumnIndex("date"));
                int weightId = cursor.getInt(cursor.getColumnIndex("weight_id"));

                TableRow row = new TableRow(this);

                TextView tvWeight = new TextView(this);
                tvWeight.setText(String.valueOf(weight));
                tvWeight.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1));
                row.addView(tvWeight);

                TextView tvDate = new TextView(this);
                tvDate.setText(date);
                tvDate.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1));
                row.addView(tvDate);

                // This should be the button for removing weight.
                Button removeButton = new Button(this);
                removeButton.setText("Remove");
                removeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        removeWeight(weightId);
                        // This should refresh the displayed weights after removal.
                        displayWeights();
                    }
                });
                row.addView(removeButton);

                // This should be a button for editing weight.
                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editWeight(weightId);
                        // This should refresh the displayed weights.
                        displayWeights();
                    }
                });
                row.addView(editButton);

                tableLayoutWeights.addView(row);
            } while (cursor.moveToNext());
        }

        cursor.close();
    }

    // This should be the method to remove a weight.
    private void removeWeight(int weightId) {
        try {
            database.execSQL("DELETE FROM weights WHERE weight_id = " + weightId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // This should be the method to edit a weight.
    private void editWeight(int weightId) {
        // This should retrieve the current weight for the given weightId.
        Cursor cursor = database.rawQuery("SELECT * FROM weights WHERE weight_id = " + weightId, null);

        if (cursor.moveToFirst()) {
            double currentWeight = cursor.getDouble(cursor.getColumnIndex("weight"));

            // This should create a dialog to edit the weight.
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Edit Weight");

            // This should create an EditText for the user to enter the new weight.
            EditText newWeightEditText = new EditText(this);
            newWeightEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            newWeightEditText.setText(String.valueOf(currentWeight));

            builder.setView(newWeightEditText);

            // This should set the positive button for updating the weight.
            builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // This should get the new weight from the EditText.
                    String newWeightStr = newWeightEditText.getText().toString();

                    if (!newWeightStr.isEmpty()) {
                        double newWeight = Double.parseDouble(newWeightStr);

                        // This should update the weight in the database.
                        try {
                            database.execSQL("UPDATE weights SET weight = " + newWeight + " WHERE weight_id = " + weightId);
                            // This should refresh the displayed weights after updating.
                            displayWeights();
                            Toast.makeText(DailyWeightActivity.this, "Weight updated successfully", Toast.LENGTH_SHORT).show();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(DailyWeightActivity.this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // This should set negative button for canceling the edit operation.
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // This should dismiss the dialog.
                    dialogInterface.dismiss();
                }
            });

            // This should show the dialog.
            builder.show();
        }

        cursor.close();
    }


    private void displayGoalWeight() {
        WeightRepository weightRepository = new WeightRepository(this);
        weightRepository.open();
        double goalWeight = weightRepository.getGoalWeight("1");
        weightRepository.close();

        goalWeightTextView.setText("Goal Weight: " + goalWeight);
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }
}