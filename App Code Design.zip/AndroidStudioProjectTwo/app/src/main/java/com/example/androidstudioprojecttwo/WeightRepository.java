
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.text.format.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class WeightRepository {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public WeightRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void createTable() {
        try {
            database.execSQL("CREATE TABLE IF NOT EXISTS " + DatabaseHelper.TABLE_WEIGHTS +
                    " (" + DatabaseHelper.COLUMN_USER_ID + " INTEGER, " +  // Change to INTEGER
                    DatabaseHelper.COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    DatabaseHelper.COLUMN_WEIGHT + " REAL, " +
                    DatabaseHelper.COLUMN_DATE + " TEXT)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public long addGoalWeight(String userId, double goalWeight) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_GOAL_WEIGHT, goalWeight);

        // This should delete existing goal weight, if there is one.
        database.delete(DatabaseHelper.TABLE_GOAL_WEIGHTS, DatabaseHelper.COLUMN_USER_ID + "=?", new String[]{userId});

        // This should insert a goal weight.
        return database.insert(DatabaseHelper.TABLE_GOAL_WEIGHTS, null, values);
    }

    public double getGoalWeight(String userId) {
        String[] columns = {DatabaseHelper.COLUMN_GOAL_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.TABLE_GOAL_WEIGHTS, columns,
                DatabaseHelper.COLUMN_USER_ID + "=?", new String[]{userId},
                null, null, null);

        double goalWeight = 0.0;
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL_WEIGHT));
        }

        cursor.close();
        return goalWeight;
    }

    public Cursor getAllWeights(String userId) {
        String[] columns = {DatabaseHelper.COLUMN_WEIGHT_ID, DatabaseHelper.COLUMN_WEIGHT, DatabaseHelper.COLUMN_DATE};
        return database.query(DatabaseHelper.TABLE_WEIGHTS, columns,
                DatabaseHelper.COLUMN_USER_ID + " = ?", new String[]{userId},
                null, null, null);
    }

    public long addDailyWeight(String userId, double weight) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USER_ID, userId);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);
        values.put(DatabaseHelper.COLUMN_DATE, getCurrentDate());

        return database.insert(DatabaseHelper.TABLE_WEIGHTS, null, values);
    }


    public Cursor getAllWeights() {
        String[] columns = {DatabaseHelper.COLUMN_WEIGHT_ID, DatabaseHelper.COLUMN_WEIGHT, DatabaseHelper.COLUMN_DATE};
        return database.query(DatabaseHelper.TABLE_WEIGHTS, columns, null, null, null, null, null);
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    private boolean isTableExists(String tableName) {
        Cursor cursor = database.rawQuery("SELECT DISTINCT tbl_name FROM sqlite_master WHERE tbl_name = '" + tableName + "'", null);
        boolean tableExists = cursor.getCount() > 0;
        cursor.close();
        return tableExists;
    }


}
