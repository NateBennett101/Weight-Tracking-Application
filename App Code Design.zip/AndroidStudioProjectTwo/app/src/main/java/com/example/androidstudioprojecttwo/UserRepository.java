
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserRepository {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    private NavigationCallback navigationCallback;

    public UserRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long createUser(User user) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, user.getUsername());
        values.put(DatabaseHelper.COLUMN_PASSWORD, user.getPassword());

        return database.insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    public boolean isValidUser(String username, String password) {
        String[] columns = {DatabaseHelper.COLUMN_USER_ID};
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = database.query(DatabaseHelper.TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean isValid = cursor.getCount() > 0;

        cursor.close();
        return isValid;
    }

    public boolean isUsernameTaken(String username) {
        String[] columns = {DatabaseHelper.COLUMN_USER_ID};
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = database.query(
                DatabaseHelper.TABLE_USERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean isTaken = cursor.getCount() > 0;

        cursor.close();
        return isTaken;
    }


    // This should be a function to check if a user exists by username.
    public boolean doesUserExist(String username) {
        String[] columns = {DatabaseHelper.COLUMN_USER_ID};
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = database.query(
                DatabaseHelper.TABLE_USERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();
        return exists;
    }

    // This should be a method to navigate to the Create Account screen.
    public void navigateToCreateAccount() {
        if (navigationCallback != null) {
            navigationCallback.onNavigateToCreateAccount();
        }
    }

    // This should be a callback interface for navigation.
    public interface NavigationCallback {
        void onNavigateToCreateAccount();
    }
}
