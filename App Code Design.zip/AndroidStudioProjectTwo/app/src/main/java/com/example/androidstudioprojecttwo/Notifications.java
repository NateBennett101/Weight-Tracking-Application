
// Nate Bennett

package com.example.androidstudioprojecttwo;

import android.telephony.SmsManager;

public class Notifications {
    public static void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}
